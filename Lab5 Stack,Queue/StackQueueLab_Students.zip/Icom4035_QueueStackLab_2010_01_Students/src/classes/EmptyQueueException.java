package classes;

public class EmptyQueueException extends RuntimeException {

	public EmptyQueueException() {
		// TODO Auto-generated constructor stub
	}

	public EmptyQueueException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmptyQueueException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmptyQueueException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
