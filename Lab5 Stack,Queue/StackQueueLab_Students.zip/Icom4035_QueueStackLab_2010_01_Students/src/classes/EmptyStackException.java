package classes;

public class EmptyStackException extends RuntimeException {

	public EmptyStackException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmptyStackException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmptyStackException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EmptyStackException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
